# This is a program to set up and implement the menu options.
# Program written by: Benjamin,Andrew,  Shukrullah, Artem, Coby, Evans(Group5)
# Written from November 30, 2023 to December 7, 2023. 
 
# Import any required libraries
#import formatValues as FV
import datetime 
import FormatValues as fv
from tqdm import tqdm
import time


# Create a Defaults.dat file with the specified values.
with open("Defaults.dat", "w") as file: 
    file.write("Next transaction number: 143\n")
    file.write("Next driver number: 1922\n")
    file.write("Monthly stand fee: 175.00\n")
    file.write("Daily rental fee: 60.00\n")
    file.write("Weekly rental fee: 300.00\n")
    file.write("HST rate: .15\n")


# Read values from the Defaults.dat file into variables.
with open("Defaults.dat", "r") as file:
    NextTransactionNum = int(file.readline().split(":")[1].strip())
    NextDriverNum = int(file.readline().split(":")[1].strip())
    MonthlyStandFee = float(file.readline().split(":")[1].strip())
    DailyRentFee = float(file.readline().split(":")[1].strip())
    WklyRentFee = float(file.readline().split(":")[1].strip())
    HstRate = float(file.readline().split(":")[1].strip())


# Set up program functions.
def NewEmployee():
    # Comment for the description.
      pass
def CompanyRevenue():
    # Comment description.
    pass
def CompanyExpenses():
    # Comment.
    pass
def CarRentals():
    # Comment.
    pass
def EmployeePayment():
    # Comment.
    pass
def CompanyProfitListing():
    # Comment.
     pass
def DriverProfitListing():
    # Comment.
    pass
def DriverAnalysisReport():
    # Comment.
    pass

   # Start the main menu program.
while True:
    print()
    print()
    print("HAB Taxi Services")
    print("Company Services System")
    print("1. Enter a New Employee (driver).")
    print("2. Enter Company Revenues.")
    print("3. Enter Company Expenses.")
    print("4. Track Car Rentals.")
    print("5. Record Employee Payment.")
    print("6. Company Profit Listing.")
    print("7. Driver Financial Listing.")
    print("8. Driver Analysis Report.")
    print("9. Quit Program")
    print()
    print()
    while True:
        try:
            Choice = int(input("Enter choice (1-9): "))
        except:
            print("Error - menu choice is invalid - must be between 1 and 9.")
        else:
            if Choice < 1 or Choice > 9:
                print("Error - choice must be between 1 and 6.")
            else:
                break  

    if Choice == 1:
        NewEmployee()
    elif Choice == 2:
        CompanyRevenue()
    elif Choice == 3:
        CompanyExpenses()
    elif Choice == 4:
        CarRentals()
    elif Choice == 5:
        EmployeePayment()
    elif Choice == 6:
        CompanyProfitListing()
    elif Choice == 7:
        DriverProfitListing()
    elif Choice == 8: 
        DriverAnalysisReport()
    else:
        break
    

    # Implementing option 2 ( Entering company revenues).
    # Input revenue details from the ERD.
    # Validating  inputs. 
    # Converting transaction date to datetime object.

    while True:
        try:
            TransId = int(input("Enter the transaction ID:  "))
        except:
            print("TransactionID is not a valid number- please re-enter.")
        else:
            break


    TransDate = datetime.datetime.now()
    TransDate = datetime.datetime.strftime(TransDate,"%Y-%m-%d")
    while True:
        TransDate = input("Enter the transaction date (YYYY-MM-DD)::  ")
        if TransDate =="":
            print("Transaction date cannot be blank- please use valid format.")
        else:
            break


    while True:
        TransDescription = input("Enter the transaction description:  ")
        if TransDescription =="":
            print("Transaction description cannot be blank- please re-enter.")
        else:
            break


    while True:
        try:
            DriverNum = int(input("Enter the driver number:  "))
        except:
            print("Driver number is not a valid number- please re-enter.")
        else:
            break


    while True:
        try:
            TransAmount = float(input("Enter the transaction amount:  "))
        except:
            print("Invalid numeric value - Please re-enter valid number.")
        else:
            break


    while True:
        try:
            HstRate = float(input("Enter the HST rate:  ")) # HST rate is provided as( 0.15 for 15%)
    
        except:
            print("Invalid numeric value - Please re-enter valid number.")
        else:
            break
    
    while True:
        try:
            TransTotal = float(input("Enter the transaction total:  "))
        except:
            print("Invalid numeric value - Please re-enter valid number.")
        else:
            break


    # Required Calculations for HST and Total
        
    if TransDescription == "Weekly Stand Fees":
       TransAmount = MonthlyStandFee

    if TransDescription == "Weekly Rental Fees":
       TransAmount = WklyRentFee
    
    if TransDescription == "Daily Rental Fees":
        TransAmount = DailyRentFee
    
    HST = TransAmount * HstRate

    Total = TransAmount + HST

    print()
    # Displaying the results of a driver transaction details making it simple.
    print(f"TransactionID: {TransId}")
    print(f"Driver Number: {DriverNum}")
    print(f"Transaction Total: {TransTotal}")


    # Writing the values to a file for future reference with mode = "a", newline = "".
    # Using progress bar to let the user know that something is happenning.
    # Create a range of values to iterate over
    data = range(10)

    # Wrap the iterable with tqdm to create a progress bar
    for item in tqdm(data, desc="Processing", unit="item"):
        # Creating some work
     time.sleep(0.1)

    # The loop is complete when the progress bar reaches 100%
    print("Processing complete!")

    f = open("Revenues.dat", "a")

    f.write("{}, ".format((TransId)))
    f.write("{}, ".format(str(TransDate)))
    f.write("{}, ".format(TransDescription))
    f.write("{}, ".format(DriverNum))
    f.write("{}, ".format(str(TransAmount)))
    f.write("{}, ".format(str(HST)))
    f.write("{}, ".format(str(TransTotal)))

    f.close()
    # incrementing the transactionId and driver number for the next processing time.
    TransId +=1
    DriverNum +=1
    print()
    print("Revenues data have been successfully saved to (Revenues.dat).")
    print()
     # Created data file for company revenues(Revenues.dat) with 20 records.
     # Created data file for New employees (NewEmployees.dat) with 5 recods.
     # Created data file for company expenses(Expenses.dat) with 20 records.
    
     # Initialize Balance due. It would be updated.
    BalanceDue = 0.00
    
    
    # Process to follow when generating driver financial listing  report(option 7)
    # Printing the main headings and column headings.
    Today = datetime.datetime.now()
    TodayDsp = datetime.datetime.strftime(Today,"%Y-%m-%d")
    print()
    print(f"HAB TAXI SERVICES")
    print(f"DRIVER FINANCIAL LISTING INVOICE AS OF {TodayDsp:<10s}")
    print()
    print(f"TRANSACTION   DRIVER     TRANSACTION   TRANSACTION   HST     TOTAL")
    print(f"ID            NUMBER      DATE          AMOUNT")
    print("=====================================================================")

    # Initialize counters and accumulators for summary / analytics.
    DriverCtr = 0
    TransAmountAcc = 0
    HSTAcc = 0
    TotalAcc = 0


    # Open the file with the "r" mode for read.
    f = open("Revenues.dat", "r")
    # Set up the loop to process all the records in the file.
    for DriverRecord in f:      
        # Input - read the first record and split into a list.
        DriverList = DriverRecord.split(",")
   
        #Assigning variables to each item in the list that are required in the report.
        # The .strip() method removes any spaces in the front or back of a value.
        TransId = DriverList[0].strip()
        TransDate = DriverList[1].strip()
        DriverNum = int(DriverList[3].strip())
        TransAmount = float(DriverList[4].strip())
        HST = float(DriverList[5].strip())
        Total = float(DriverList[6].strip())
   
        # Required Calculations

        if TransDescription == "Weekly Stand Fees":
            TransAmount = MonthlyStandFee

        if TransDescription == "Weekly Rental Fees":
            TransAmount = WklyRentFee
    
        if TransDescription == "Daily Rental Fees":
            TransAmount = DailyRentFee
    
        HST = TransAmount * HstRate 

        Total = TransAmount + HST
        
        
        # Print the detail line.  A detail line is the details of the record required.
        TransDate = datetime.datetime.now()
        TransDateDsp = datetime.datetime.strftime(TransDate, "%Y-%m-%d")
        print(f"{TransId:<4s}          {DriverNum:>2d}     {TransDateDsp:<12s}    {fv.FDollar2(TransAmount):<8s}     {fv.FDollar2(HST):<7s}   {fv.FDollar2(Total):<8s}")
    

        # Increment and Accumulate the summary / analytics data.
        DriverCtr += 1
        TransAmountAcc +=TransAmount
        HSTAcc += HST
        TotalAcc += Total
    # Close the file.
    f.close()
    # Print the summary / analytics data.
    print("======================================================================")
    print(f"TOTAL DRIVERS LISTED: {DriverCtr:>2d}             {fv.FDollar2(TransAmountAcc):>8s}     {fv.FDollar2(HSTAcc):>8s}  {fv.FDollar2(TotalAcc):>10s}")              
    print()
     
     
     # Updating balance due  by $175.00 based on driver with their own vehicle.
    OwnCar = input("Do you have your own car?(Y/N): ").upper()
    if OwnCar=="Y":
        BalanceDue += 175.00
    

    print()
    # Process to follow when generating driver analysis report (option 8).
    # Printing the main headings and column headings.
    Today = datetime.datetime.now()
    TodayDsp = datetime.datetime.strftime(Today,"%Y-%m-%d")
    print()
    print(f"                      HAB TAXI SERVICES")
    print()
    print(f"       DRIVER ANALYSIS REPORT AS OF {TodayDsp:<10s}")
    print()
    print(f"DRIVER     DRIVER             PHONE               BALANCE")
    print(f"NUMBER      NAME              NUMBER                DUE")
    print("=============================================================")

     # Initialize counters and accumulators for summary / analytics.
    DriverCtr = 0
    BalanceDueAcc = 0
    
     # Open the file with the "r" mode for read.
    f = open("NewEmployees.dat", "r")
    # Set up the loop to process all the records in the file.
    for DriverRecord in f:      
        # Input - read the first record and split into a list.
        DriverList = DriverRecord.split(",")

        #Assigning variables to each item in the list that are required in the report.
        # The .strip() method removes any spaces in the front or back of a value.
        DriverNum = int(DriverList[0].strip())
        DriverName = DriverList[1].strip()
        PhoneNum =  DriverList[6].strip()
        BalanceDue = float(DriverList[12].strip())

        # No required calculation in this report.


        # Print the detail line.  A detail line is the details of the record required.
        print(f"{DriverNum:>4d}     {DriverName:<20s} {PhoneNum:<20s}  {fv.FDollar2(BalanceDue):<10s}")
    

        # Increment and Accumulate the summary / analytics data.
        DriverCtr += 1
        BalanceDueAcc +=BalanceDue
        
    # Close the file.
    f.close()

    # Print the summary / analytics data.
    print("============================================================")
    print(f"Drivers Listed: {DriverCtr:>2d}                                  {fv.FDollar2(BalanceDueAcc):<10s}")              
    print()
    print(f"                           END OF LISTING")
    print()

     # Write the current values back to the Defaults file. 
     # Used  “w” to overwrite.
     # Used \n so that each value is placed on a separate line.
    f = open('Defaults.dat', 'w')
    f.write("{}\n".format(str(NextTransactionNum)))
    f.write("{}\n".format(str(NextDriverNum)))
    f.write("{}\n".format(str(MonthlyStandFee)))
    f.write("{}\n".format(str(DailyRentFee)))
    f.write("{}\n".format(str(WklyRentFee)))
    f.write("{}\n".format(str(HstRate)))
    f.close()
    print()
print("Thanks for using the menu System.")
print("Have a great day!")
